#!/usr/bin/python
import arm_to_uppaal_compiler
import pyuppaal
import sys
import combine
import os

def verify_wcet(modelfilename, remotehost=None, verbose=False):
    #Produce query file using pyuppaal
    queryfile = pyuppaal.QueryFile('sup: cyclecounter')
    (fh, path) = queryfile.getTempFile()
    
    #invoke verifyta using pyuppaal
    (res, output) = pyuppaal.verify(modelfilename, fh.name, searchorder='dfs',
                            remotehost=remotehost, getoutput=True)
    
    #Delete file
    queryfile.deleteTempFile(fh)

    if verbose:
        print output
    
    #return whether query is satisfied
    wcet = int(res[0].replace('cyclecounter <= ', ''))
    return wcet

if __name__ == "__main__":
    if '--remote' in sys.argv:
        print 'remotely'
    #add outputfilename.xml to combine cmdline
    modelfilename = '/tmp/test.xml'
    sys.argv += [modelfilename]

    optparser = combine.createOptionParser(usage="usage: %prog [options] objfilename")


    (options, args) = optparser.parse_args()

    combine.main(optparser, options, args)
    
    wcet = verify_wcet(modelfilename=modelfilename, remotehost=options.remotehost, verbose=options.verbose)

    print "%d is a WCET upper bound" % wcet
