#!/bin/sh
output=build.log

. ./prepare.sh

echo Creating $output ...

for i in ../wcet_bench/web/*; do
    n=`basename "$i"`
    objfile="$i/$n-O0.o"
    if [ -x  $objfile ]; then
        if [ "abemad" != "ostepops" \
                -a "$n" != "adpcm" \
                -a "$n" != "bsort100" \
                -a "$n" != "compress" \
                -a "$n" != "cover" \
                -a "$n" != "duff" \
                -a "$n" != "fdct" \
                -a "$n" != "fft1" \
                -a "$n" != "lcdnum" \
                -a "$n" != "lms" \
                -a "$n" != "ludcmp" \
                -a "$n" != "minver" \
                -a "$n" != "ndes" \
                -a "$n" != "nsichneu" \
                -a "$n" != "qsort-exam" \
                -a "$n" != "qurt" \
                -a "$n" != "select" \
                -a "$n" != "statemate" \
                -a "$n" != "ud" \
                -a "$n" != "matmult" \
                ]; then
                echo "$n"
                echo "$n" | sed 's/./=/g'
                #./combine.py $objfile /tmp/build_log_"$n".xml $* 2>&1
                time ./verify_wcet.py $objfile $* 2>&1
        
                echo
                echo
        fi

        #if [ "$n" = "matmult" ]; then
        #        echo "$n"
        #        echo "$n" | sed 's/./=/g'
        #        #./combine.py "$i/$n.o" /tmp/build_log_"$n".xml $* 2>&1
        #        time ./verify_wcet.py --no-value-analysis -d miss "$i/$n.o" $* 2>&1
        #
        #        echo
        #        echo
        #fi
    fi
done > $output
pcregrep -M -c '==\n\n' $output
