#!/usr/bin/python

"""
    This program is used to generate cache models for uppaal.

    Copyright (C) 2008 Andreas Engelbredt Dalsgaard <andreas.dalsgaard@gmail.com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>. """

import pyuppaal
from pyuppaal import *
import os
import sys
import shutil

# type: 'd', 'data', 'i' or 'instruction'
# blockSize, lines, sets: integers
# writeHit: 'WRITE_BACK' (default) or 'WRITE_THROUGH'
# writeMiss: 'WRITE_ALLOCATE' (default) or 'NO_WRITE_ALLOCATE'
# replacementPolicy: 'FIFO' (default) or 'LRU'

def cache_gen(type, blockSize, lines, sets, writeHit = 'WRITE_BACK', writeMiss = 'WRITE_ALLOCATE', replacementPolicy = 'FIFO'):

    file = open('models/cache.xml')

    replacePolicy = []
    replacePolicy += ['cacheHit%s(adr, write);' % (replacementPolicy) ]
    replacePolicy += ['}']
    replacePolicy += ['']
    replacePolicy += ['void insert(address adr, bool write)']
    replacePolicy += ['{']
    replacePolicy += ['cacheMiss%s(adr, write);' % (replacementPolicy) ]
    replacePolicy += ['}']

    consts = []
    consts += ['const int BLOCKSIZE = %d;' % (blockSize)]
    consts += ['const int CACHELINES = %d;' % (lines)]
    consts += ['const int CACHESETS = %d;' % (sets)]
    consts += ['const int CACHEFETCH = %d;' % (1)]
    consts += ['']
    consts += ['const bool WRITE_BACK = 0;']
    consts += ['const bool WRITE_THROUGH = 1;']
    consts += ['const bool write_hit = %s;	//set to either WRITE_BACK or WRITE_THROUGH' % writeHit]
    consts += ['const bool WRITE_ALLOCATE = 0;']
    consts += ['const bool NO_WRITE_ALLOCATE = 1;']
    consts += ['const bool write_miss = %s;	//set to either WRITE_ALLOCATE or NO_WRITE_ALLOCATE' % writeMiss] 

    if type in ['d', 'data']:
        cacheType = 'dataCache'
        ntaCacheModel = pyuppaal.from_xml(file)       
        newDeclarations = '\naddress cacheDataAdr;\nurgent chan dataCacheRead, dataCacheWrite, dataCacheMainMemory;\n'
        tmpStr = ntaCacheModel.templates[0].declaration
        ntaCacheModel.templates[0].declaration = '\n'.join(consts)
        ntaCacheModel.templates[0].declaration += tmpStr
        ntaCacheModel.templates[0].declaration += '\n'.join(replacePolicy) 
    elif type in ['i', 'instruction']:
        cacheType = 'instructionCache'
        #hack, search replace dataCache/instructionCache and remove all lines containing dirty
        text = file.read()
        tmpFile = open('/tmp/thsdk1l2.xml', 'w')
        text = text.replace('dataCache', 'instructionCache')
        tmpFile.write(text.replace('cacheDataAdr', 'cacheInstrAdr'))
        tmpFile.close()
        ntaCacheModel = pyuppaal.from_xml(open('/tmp/thsdk1l2.xml', 'r'))
        ntaCacheModel.templates[0].name = 'InstructionCacheTemplate'
        text = ntaCacheModel.templates[0].declaration 
        cleanLines = []
        for l in text.splitlines(True):
            if l.count('dirty') == 0:
                cleanLines.append(l)
        
        ntaCacheModel.templates[0].declaration = '\n'.join(consts)
        ntaCacheModel.templates[0].declaration += ''.join(cleanLines)
        ntaCacheModel.templates[0].declaration += '\n'.join(replacePolicy) 
        newDeclarations = '\naddress cacheInstrAdr;\nurgent chan instructionCacheRead, instructionCacheWrite, instructionCacheMainMemory;\n'
     
    if ntaCacheModel.declaration == None:
        ntaCacheModel.declaration = newDeclarations 
    else:
        ntaCacheModel.declaration += newDeclarations

    return ntaCacheModel


def cache_gen_always(type, always):
    file = open('models/cache_always_' + always + '.xml')

    if type in ['d', 'data']:
        cacheType = 'dataCache'
        ntaCacheModel = pyuppaal.from_xml(file)       
        newDeclarations = '\naddress cacheDataAdr;\nurgent chan dataCacheRead, dataCacheWrite, dataCacheMainMemory;\n'
        tmpStr = ntaCacheModel.templates[0].declaration
        ntaCacheModel.templates[0].declaration = ''
        ntaCacheModel.templates[0].declaration += tmpStr
    elif type in ['i', 'instruction']:
        cacheType = 'instructionCache'
        #hack, search replace dataCache/instructionCache and remove all lines containing dirty
        text = file.read()
        tmpFile = open('/tmp/thsdk1l2.xml', 'w')
        text = text.replace('dataCache', 'instructionCache')
        tmpFile.write(text.replace('cacheDataAdr', 'cacheInstrAdr'))
        tmpFile.close()
        ntaCacheModel = pyuppaal.from_xml(open('/tmp/thsdk1l2.xml', 'r'))
        ntaCacheModel.templates[0].name = 'InstructionCacheTemplate'
        text = ntaCacheModel.templates[0].declaration 
        cleanLines = []
        for l in text.splitlines(True):
            if l.count('dirty') == 0:
                cleanLines.append(l)
        
        ntaCacheModel.templates[0].declaration = ''
        ntaCacheModel.templates[0].declaration += ''.join(cleanLines)
        newDeclarations = '\naddress cacheInstrAdr;\nurgent chan instructionCacheRead, instructionCacheWrite, instructionCacheMainMemory;\n'
    if ntaCacheModel.declaration == None:
        ntaCacheModel.declaration = newDeclarations 
    else:
        ntaCacheModel.declaration += newDeclarations

    return ntaCacheModel

if __name__ == "__main__":
    if len(sys.argv) < 6:
        print 'Usage: %s outputfilename.xml d[ata]/i[nstruction] blocksize cachelines cachesets [WRITE_BACK/WRITE_THROUGH] [WRITE_ALLOCATE/NO_WRITE_ALLOCATE] [FIFO/LRU]' % (sys.argv[0])
        sys.exit(1)

    writeHit = 'WRITE_BACK'
    writeMiss = 'WRITE_ALLOCATE'
    replacementPolicy = 'FIFO'
    for i in range(6, len(sys.argv)):
        if sys.argv[i] == 'WRITE_THROUGH':
            writeHit = sys.argv[i]
        if sys.argv[i] == 'NO_WRITE_ALLOCATE':
            writeMiss = sys.argv[i]
        if sys.argv[i] == 'LRU':
            replacementPolicy = sys.argv[i]

    ntaCacheModel = cache_gen(sys.argv[2], int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5]), writeHit, writeMiss, replacementPolicy)

    if os.path.exists(sys.argv[1]):
        outf = open(sys.argv[1], 'r')
        ntaMerge = pyuppaal.from_xml(outf)
        outf.close()
        for t in ntaMerge.templates:
            if ntaCacheModel.templates[0].name == t.name:
                print 'Error: Trying to add template with same name as template in '+sys.argv[1]
                sys.exit(1)

        ntaMerge.add_template(ntaCacheModel.templates[0])
        ntaMerge.declaration += ntaCacheModel.declaration
        ntaCacheModel = ntaMerge

    outf = open(sys.argv[1], 'w')
    outf.write(ntaCacheModel.to_xml())
    outf.close()
    sys.exit(0)
