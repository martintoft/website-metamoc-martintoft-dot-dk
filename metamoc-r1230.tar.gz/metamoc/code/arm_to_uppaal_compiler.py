#!/usr/bin/env python

import sys
import dissy.File
import pyuppaal
from cache_gen import cache_gen
from dissy.Function import Function
from dissy.Instruction import Instruction
from dissy.arm import ArmArchitecture
from dissy.arm import arm_conditions
import re
from common import all_loopbound_combinations, find_loopbounds, handled_library_functions

def clean_identifier(id):
    for a in '# []{}-!.,':
        id = id.replace(a, '_')
    while '__' in id:
        id = id.replace('__', '_')
    return id

def clean_funcname(fname):
    """Rename function names, s.t. they do not conflict with identifiers
    used in the model."""
    if fname in ['fetch', 'decode', 'memory', 'writeback', 'main_done', 
        'fetch_done', 'decode_done', 'execute_done', 'memory_done',
        'init', 'select']:
        #XXX if something is already called this?
        return fname + "0"
    else:
        return fname

safety_warning = False
def print_safety_warning(w):
    global safety_warning
    safety_warning = True
    print "SAFETY ERROR:", w

accuracy_warning = False
print_warning = True
def print_inaccurate_warning(w):
    global accuracy_warning, print_warning
    accuracy_warning = True
    if print_warning == True:
        print "Accuracy warning:", w

def crossproduct(s1, s2):
    ans = []
    for a in s1:
        for b in s2:
            ans += [a + b]
    return ans

def get_ins_type(opcode):
    if opcode in crossproduct(['stm', 'stmda', 'stmdb', 'stmia', 'stmib',
                               'str', 'strb', 'strh', 'strsh'],
                              arm_conditions.keys() + ['']):
        #print_inaccurate_warning("'%s' not handled accurately yet!" % opcode)
        return 'INSTR_STORE'
    elif opcode in crossproduct(['ldm', 'ldmda', 'ldmdb', 'ldmia', 'ldmib',
                                 'ldr', 'ldreq', 'ldrls'],
                                arm_conditions.keys() + ['']):
        #print_inaccurate_warning("'%s' not handled accurately yet!" % opcode)
        return 'INSTR_LOAD'
    elif opcode in crossproduct(['ldrb', 'ldrh', 'ldrsh'],
                                arm_conditions.keys() + ['']):
        print_inaccurate_warning("'%s' not handled accurately yet!" % opcode)
        return 'INSTR_LOADROTATE'
    elif opcode == 'push':
        #print_inaccurate_warning("'push' not handled accurately yet!")
        return 'INSTR_PUSH'
    elif opcode == 'pop':
        #print_inaccurate_warning("'pop' not handled accurately yet!")
        return 'INSTR_POP'
    #"common" instructions
    elif opcode in crossproduct(['add', 'adds', 'and', 'asr', 'asrs', 'cmn',
                                 'cmp', 'eor', 'eors', 'lsl', 'lsls', 'lsr',
                                 'lsrs', 'mov', 'mvn', 'orr', 'orrs', 'rsb',
                                 'rsbs', 'sub', 'subs', 'tst', 'movs', 'teq'],
                                 arm_conditions.keys() + ['']):
        return "INSTR_OTHER"
    elif opcode in crossproduct(['mul', 'mla', 'muls'],
                                arm_conditions.keys() + ['']):
        return "INSTR_MUL1"
    elif opcode in crossproduct(['smull', 'umull', 'smlal', 'umlal'],
                                arm_conditions.keys() + ['']):
        return "INSTR_MUL2"
    #branches to static locations
    elif opcode in crossproduct(['b', 'bl', 'bx'], arm_conditions.keys() + ['']):
        return "INSTR_OTHER"
    else:
        print_safety_warning("Unhandled opcode '" + opcode + "'")
        return "INSTR_OTHER"

arch = ArmArchitecture()
def get_reg_args(instr):
    (regsread, regswrite, values) = arch.parseArguments(instr)
    regsread = ['REG_' + r.upper() for r in regsread]
    regswrite = ['REG_' + r.upper() for r in regswrite]
    if regsread == []:
        regsread = ['REG_NONE']
    if regswrite == []:
        regswrite = ['REG_NONE']
    return (regsread, regswrite)

def set_last_loop_bound(line, last_loop_bound):
    p = re.compile('@loop_bound\ ([0-9]+)')
    l = p.findall(str(line))
    if len(l) > 0:
        return l[len(l) - 1]
    else:
        return last_loop_bound

def find_forward_escape_jumps(jforward, jback):
    forward_escape_jumps = []
    for (jb_fromins, jb_toins) in jback.values():
        for jf in jforward.values():
            (jf_fromins, jf_toins) = jf
            if jf_fromins.address < jb_fromins.address and jf_fromins.address > jb_toins.address:
                if jf_toins.address > jb_fromins.address:
                    print_safety_warning("Forward jump out of loop, may be unsafe and result in lots of nondeterminisme")
                    forward_escape_jumps.append(jf)

    return forward_escape_jumps

def adjust_start_address(instr, start_address):
    #see section A5.4 (pages 481-488) in the ARM Architecture Reference Manual
    opcode = instr.getOpcode()
    if not opcode in crossproduct(['ldm', 'stm'], ['da', 'db', 'ib']):
        return start_address
    #handle increase before
    if opcode[3:5] == 'ib':
        return start_address + 4
    (regsread, regswrite) = get_reg_args(instr)
    if opcode[0:3] == 'ldm':
        regs = regswrite
    else:
        regs = regsread
    if regs == ['REG_NONE']:
        regs_specified = 0
    else:
        regs_specified = len(regs)
    if 'REG_SP' in regs:
        regs_specified -= 1
    #decrement after and decrement before are handled in the same way
    return start_address - regs_specified * 4 + 4

def make_template(func, jforward, jback, funcname, value_anal_res={}):
    ins_to_loc = {}
    transitions = []
    extra_locs = []
    ypos = 0
    branch_number = 0
    declarations = ''
    
    find_forward_escape_jumps(jforward, jback)

    #check that .word's are the last in a function, and no instructions follow
    word_seen = False
    for ins in func.getInstructions():
        if ins.getOpcode() == '.word':
            word_seen = True
        elif word_seen:
            print_safety_warning("Instruction after '.word'")
            break

    for ins in func.getInstructions():
        if ins.getOpcode() != '.word':
            loc = pyuppaal.Location(name=clean_identifier('i' + \
                  hex(ins.address)[:-1] + '_' + ins.getOpcode() + '_' + \
                  ins.getArgs()), ypos = ypos)
            ypos += 100
            ins_to_loc[ins] = loc

    #functions (not main) need to initialise loop counters at each
    #call - add an extra location and transition to do that
    if funcname != 'main':
        startloc = pyuppaal.Location()
        transitions += [pyuppaal.Transition(startloc,
                                            ins_to_loc[
                                            func.getInstructions()[0]],
                                            synchronisation = funcname + \
                                            '_branch?')]

    #an extra location is required because
    #instructions are represented by transitions
    endloc = pyuppaal.Location()

    loop_bounds = find_loopbounds(func)

    #make sequential transitions
    for i in range(0, len(func.getInstructions())):
        ins = func.getInstructions()[i]

        if ins.getOpcode() == '.word':
            continue

        (regsread, regswrite) = get_reg_args(ins)
        
        #warn if a non-branch instruction writes to the program counter
        if 'REG_PC' in regswrite and not ins.getOpcode() in \
            crossproduct(['b', 'bl', 'bx'], arm_conditions.keys() + ['']):
            print_safety_warning('Write to program counter: %s %s %s' %
                                 (hex(ins.address)[:-1], ins.getOpcode(),
                                 ins.getArgs()))

        assignments = []
        assignments += ['instradr[PIPELINE_FETCH_STAGE] = %s' % (ins.address)]
        assignments += ['instrtype[PIPELINE_FETCH_STAGE] = %s' %
                        (get_ins_type(ins.getOpcode()))]

        value = value_anal_res.get(ins.getAddress(), None)
        if isinstance(value, int):
            value = value
        elif isinstance(value, dict) and len(value) == 1:
            #optimization if only one value is defined, use ternary ?: operator
            key = value.keys()[0]
            exprs = []
            j = 0
            for a in loop_bounds:
                exprs += ['loop_counter_' + str(a) + ' == ' + str(key[j])]
                j += 1

            value = "(" + " && ".join(exprs) + ") ? " + \
                    str(adjust_start_address(ins, value[key])) + \
                    " : INVALID_ADDRESS"
        elif isinstance(value, dict) and len(value) > 0:
            lookup_matrix = 'const int dataadr_' + str(ins.getAddress())
            for a in loop_bounds.values():
                lookup_matrix += '[' + str(a) + ']'
            lookup_matrix += ' = '
            lookup_matrix += '{ ' * len(loop_bounds)

            values = list(all_loopbound_combinations(loop_bounds.values()))
            values.sort()
            prev = values[0]
            for a in values:
                for j in range(len(a)):
                    if a[j] < prev[j]:
                        #remove last ', '
                        lookup_matrix = lookup_matrix[:-2]
                        lookup_matrix += '},\n {'

                lookup_matrix += str(value.get(a, 'INVALID_ADDRESS')) + ', '

                prev = a
            #remove last ', '
            lookup_matrix = lookup_matrix[:-2]
            lookup_matrix += ' }' * len(loop_bounds) + ';'
            #TODO

            value = 'dataadr_' + str(ins.getAddress()) 
            for a in loop_bounds:
                value += '[loop_counter_' + str(a) + ']'

            declarations += lookup_matrix + '\n'
        else:
            value = 'INVALID_ADDRESS'
            
        assignments += ['dataadr[PIPELINE_FETCH_STAGE] = %s' %
                        (value)]
        assignments += ['regread[PIPELINE_FETCH_STAGE] = %s' %
                        (' | '.join(regsread))]
        assignments += ['regwrite[PIPELINE_FETCH_STAGE] = %s' %
                        (' | '.join(regswrite))]
        assignment = ',\n'.join(assignments)
        if i < len(func.getInstructions()) - 1 and \
            func.getInstructions()[i+1].getOpcode() != '.word':
            #assume .word's are only at the end of a function,
            #the first seen means the function is done
            nextloc = ins_to_loc[func.getInstructions()[i + 1]]
        elif funcname != 'main':
            nextloc = startloc
        else:
            nextloc = endloc

        #function calls (Assume no divisions by zero)
        if isinstance(ins.getOutLink(), Function) and \
            not ins.getOutLink().getLabel() in ['__div0']: #ignore call to division by zero handler 

            target = clean_funcname(ins.getOutLink().getLabel())
            callloc = pyuppaal.Location(name = 'call_' + target + '_' + \
                                        str(branch_number))
            returnloc = pyuppaal.Location(name = 'return_' + target + '_' + \
                                          str(branch_number))
            extra_locs += [callloc, returnloc]
            branch_number += 1
            transitions += [pyuppaal.Transition(ins_to_loc[ins], callloc,
                                                assignment = assignment.
                                                replace('INSTR_OTHER',
                                                'INSTR_BRANCH'),
                                                synchronisation = 'fetch!'),
                            pyuppaal.Transition(callloc, returnloc,
                                                synchronisation = target + \
                                                '_branch!')]
            #handle special case: sometimes function returns (bx lr) are
            #optimised away if the last instruction is a function call
            if funcname != 'main' and nextloc == startloc:
                returnloc2 = pyuppaal.Location()
                extra_locs += [returnloc2]
                transitions += [pyuppaal.Transition(returnloc, returnloc2,
                                                    synchronisation = \
                                                    target + '_branch?'),
                                pyuppaal.Transition(returnloc2, nextloc,
                                                    synchronisation = \
                                                    funcname + '_branch!')]
            else:
                transitions += [pyuppaal.Transition(returnloc, nextloc,
                                                    synchronisation = \
                                                    target + '_branch?')]

        #function returns (or exit from main)
        if ins.getOpcode() in crossproduct(['bx'], arm_conditions.keys() +
           ['']) and ins.getArgs() == 'lr':
            if funcname == 'main':
                transitions += [pyuppaal.Transition(ins_to_loc[ins], endloc,
                                                    assignment = assignment,
                                                    synchronisation =
                                                    'fetch!')]
            else:
                returnloc = pyuppaal.Location()
                extra_locs += [returnloc]
                transitions += [pyuppaal.Transition(ins_to_loc[ins], returnloc,
                                                    assignment = assignment.
                                                    replace('INSTR_OTHER',
                                                    'INSTR_BRANCH'),
                                                    synchronisation =
                                                    'fetch!'),
                                pyuppaal.Transition(returnloc, startloc,
                                                    synchronisation =
                                                    funcname + '_branch!')]

        #sequential progression
        if not ins.getOpcode() in ['b', 'bx'] and \
           not isinstance(ins.getOutLink(), Function):
            transitions += [pyuppaal.Transition(ins_to_loc[ins], nextloc, 
                                                assignment = assignment,
                                                synchronisation='fetch!')]


    #loop bounds/counter declarations
    init_update = ''
    for k in loop_bounds.keys():
        declarations += 'const int loop_bound_' + str(k) + ' = ' + \
                        str(loop_bounds[k])+'-1;\n'
        declarations += 'int loop_counter_' + str(k) + ';\n'
        init_update += 'loop_counter_' + str(k) + ' = 0,\n'
        if loop_bounds[k] == 'NO_LOOP_BOUND':
            print_safety_warning('missing loop bound for adr. ' + hex(k)[:-1])

    init_update = init_update[0:len(init_update)-2] #remove last ',\n'
    
    #make jump transitions
    for (fromins, toins) in jforward.values() + jback.values():
        (regsread, regswrite) = get_reg_args(fromins)

        assignments = []
        assignments += ['instradr[PIPELINE_FETCH_STAGE] = %s' %
                        fromins.address]
        assignments += ['instrtype[PIPELINE_FETCH_STAGE] = %s' %
                        get_ins_type(fromins.getOpcode())]
        assignments += ['dataadr[PIPELINE_FETCH_STAGE] = %s' %
                        ('INVALID_ADDRESS')]
        assignments += ['regread[PIPELINE_FETCH_STAGE] = %s' %
                        (' | '.join(regsread))]
        assignments += ['regwrite[PIPELINE_FETCH_STAGE] = %s' %
                        (' | '.join(regswrite))]
        assignment = ',\n'.join(assignments)
        
        guard = '' 
        if fromins.address in loop_bounds:
            guard = 'loop_counter_' + str(fromins.address) + \
                    ' < loop_bound_' + str(fromins.address)
            assignment += ',\nloop_counter_' + str(fromins.address) + '++'
            #reset counter on sequential transition, and
            #only allow to exit loop if loopbound has been reached
            outgoing_trans = [t for t in transitions if 
                              t.source == ins_to_loc[fromins]]
            assert len(outgoing_trans) <= 1
            if len(outgoing_trans) == 0:
                #create a new location, s.t. this path deadlocks 
                #(it is not a path in the real program)
                print_inaccurate_warning("Unconditional backward branch not handled effectively!")
                die_loc = pyuppaal.Location(committed=True)
                extra_locs += [die_loc]
                transitions += [pyuppaal.Transition(ins_to_loc[fromins], die_loc)]
                outgoing_trans = [t for t in transitions if 
                              t.source == ins_to_loc[fromins]]

            seq_trans = outgoing_trans[0]
            seq_trans.assignment.append('loop_counter_' + \
                                        str(fromins.address) + ' = 0')
            seq_trans.guard.append('loop_counter_' + \
                                   str(fromins.address) + ' == ' + \
                                   'loop_bound_' + str(fromins.address))

        transitions += [pyuppaal.Transition(ins_to_loc[fromins],
                                            ins_to_loc[toins],
                                            assignment = assignment.
                                            replace('INSTR_OTHER',
                                            'INSTR_BRANCH'), guard = guard,
                                            synchronisation = 'fetch!')]

    if funcname == 'main':
        initloc = pyuppaal.Location()
        endloc2 = pyuppaal.Location()
        inittrans = [pyuppaal.Transition(initloc,
                                         ins_to_loc[func.getInstructions()[0]],
                                         synchronisation = 'initCaches!',
                                         assignment = 'initialise()')]
        endtrans = [pyuppaal.Transition(endloc, endloc2,
                                        synchronisation = 'main_done!')]
        template = pyuppaal.Template(funcname + 'Template',
                                     declaration = declarations,
                                     locations = ins_to_loc.values() +
                                     extra_locs + [initloc, endloc, endloc2],
                                     transitions = transitions + inittrans +
                                     endtrans, initlocation = initloc)
    else:
        transitions[0].assignment.value = init_update
        template = pyuppaal.Template(funcname + 'Template',
                                     declaration = declarations,
                                     locations = [startloc] +
                                     ins_to_loc.values() + extra_locs,
                                     transitions = transitions, 
                                     initlocation = startloc)

    template.assign_ids()
    if len(func.getInstructions()) < 250:
        template.layout(auto_nails=True)
    else:
        global print_warning
        if print_warning == True:
            print 'Not doing auto-layout, graph to large: ' + funcname
    return template

def compile(fname, outputfname, print_warnings = True, value_anal_res = {}):
    global print_warning
    print_warning = print_warnings
    ntaPrototype = pyuppaal.NTA()
    f = dissy.File.File(fname)
    functions = []

    for func in f.getFunctions():
        if func.getLabel()[0:2] != '__' or \
            func.getLabel() in handled_library_functions:

            func.parse()
            func.link()
            (jforward, jback) = func.getJumpDicts()

            #Special case library functions
            if func.getLabel() in ['__divsi3', '__udivsi3']:
                #Ignore all forward jumps, as they are not the worst-case,
                #to decrease non-determinism
                jforward = {}

            ntaPrototype.templates.append(make_template(func, jforward, jback,
                                                        clean_funcname(func.getLabel()), value_anal_res))
            if func.getLabel() != 'main':
                ntaPrototype.declaration += '\nurgent chan ' + \
                    clean_funcname(func.getLabel()) + '_branch;'
            ntaPrototype.system = clean_funcname(func.getLabel()) + ' = ' + \
                clean_funcname(func.getLabel()) + \
                'Template();\n' + ntaPrototype.system
            functions.append(clean_funcname(func.getLabel()))

    ntaPrototype.system += ', '.join(functions) + ';'

    outf = open(outputfname, 'w')
    outf.write(ntaPrototype.to_xml())
    outf.close()

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print 'Usage: %s objfilename outputfilename.xml' % (sys.argv[0])
        sys.exit(1)

    fname = sys.argv[1]
    outputfname = sys.argv[2]

    compile(fname, outputfname)

    if safety_warning:
        sys.exit(2)
    elif accuracy_warning:
        sys.exit(1)
    sys.exit(0)
