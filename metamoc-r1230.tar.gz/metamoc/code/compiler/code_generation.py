""" 
    Copyright (C) 2008 Andreas Engelbredt Dalsgaard <andreas.dalsgaard@gmail.com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>. """

from pyuppaal.pyuppaal import *

class code_generator_uppaal:
    def __init__(self, identifiers):
        self.identifiers = identifiers
        self.loops = []
        self.locations = []
        self.transitions = []
        self.loc_init = None
        self.loc_last = None
        self.locations_forall = []
        self.transitions_forall = []

    def to_xml(self, abstractHWModelTemplate, cachesize = "4"):
        self.last_location()
        temp1 = Template("Program", "", 
                    locations=self.locations, 
                    initlocation=self.loc_init,
                    transitions=self.transitions)
        temp1.layout(auto_nails=True)
        identifier_count = str(len(self.identifiers))
        nta1 = NTA(self.clock_consts()+self.loop_consts()+"""
int tmp;
chan readInstruct;
urgent chan readData;
urgent chan writeData;
chan initAbstractHW;""",
                """
Process0 = Program();
Process1 = AbstractHWModel();
system Process0, Process1;
                """,
                [temp1, abstractHWModelTemplate])
        return nta1.to_xml()

    def clock_consts(self):
        string = ""
        i = 10
        for key, value in self.identifiers.items():
            string += "const int "+key+" = "+str(i)+";\n"
            i = i + 1
        return string
    
    def loop_consts(self):
        string = ""
        for i in range(0, len(self.loops)):
            string += "int loop_count"+str(i)+"= 0;\nconst int LOOPBOUND"+str(i)+" = "+str(self.loops[i])+";\n"
        return string

    def init_locations(self):
        if self.loc_init == None:
            self.loc_init = Location("", True)
            loc_end = Location("", True)
            self.locations.append(self.loc_init)
            self.locations.append(loc_end)
            t1 = Transition(self.loc_init, loc_end, "", "", "initAbstractHW!")
            self.transitions.append(t1)
            self.loc_last = loc_end

    def last_location(self):
        loc_end = Location("", True, "done")
        t1 = Transition(self.loc_last, loc_end)
        self.loc_last = loc_end
        self.locations.append(loc_end)
        self.transitions.append(t1)

    def read_identifier(self, identifier, loc_prev, syncAction = "readData"):
        loc1 = Location("")
        loc_end = Location("", True)
        t1 = Transition(loc_prev, loc1, "", "tmp ="+identifier, syncAction+"!")
        t2 = Transition(loc1, loc_end, "", "", syncAction+"?")
        self.locations.extend([loc1, loc_end])
        self.transitions.extend([t1, t2]) 
        self.loc_last = loc_end
    
    def write_identifier(self, identifier, loc_prev):
        self.read_identifier(identifier, loc_prev, "writeData");

    def visit_top(self, type, arg, node=None):
        if type == "program":
            self.init_locations()
        elif type == "command_if_else":
            node.children[0].visit(self, arg) #boolean expression
            loc_1 = Location("", True)
            loc_2 = Location("", True)
            loc_end = Location("", True)
            t1 = Transition(self.loc_last, loc_1)
            t2 = Transition(self.loc_last, loc_2)
            self.loc_last = loc_1
            node.children[1].visit(self, arg) #modifies self.loc_last
            loc_tmp = self.loc_last
            self.loc_last = loc_2
            node.children[2].visit(self, arg) #modifies self.loc_last
            loc_tmp2 = self.loc_last
            self.loc_last = loc_end
            t3 = Transition(loc_tmp, loc_end)
            t4 = Transition(loc_tmp2, loc_end)
            self.locations.extend([loc_1, loc_2, loc_end])
            self.transitions.extend([t1, t2, t3, t4])
            node.children = []
        elif type == "command_var":
            self.write_identifier(arg, self.loc_last);
        elif type == "expression_identifier":
            self.read_identifier(arg, self.loc_last);
        elif type == "command_while":
            local_loop_counter = len(self.loops) #to support nested loops
            self.loops.append(node.leaf)
            loc_start = Location("", True)
            loc_end = Location("", True)
            t1 = Transition(self.loc_last, loc_start, 
                    "loop_count"+str(local_loop_counter)+" < LOOPBOUND"+str(local_loop_counter))
            t2 = Transition(self.loc_last, loc_end, 
                    "loop_count"+str(local_loop_counter)+" == LOOPBOUND"+str(local_loop_counter))
            loc_prev = self.loc_last
            self.loc_last = loc_start
            node.children[0].visit(self, arg) #boolean expression, modifies self.loc_last
            node.children[1].visit(self, arg) #command in loop, modifies self.loc_last
            t3 = Transition(self.loc_last, loc_prev, "", 
                    "loop_count"+str(local_loop_counter)+" = loop_count"+str(local_loop_counter)+"+ 1")
            self.loc_last = loc_end
            self.locations.extend([loc_start, loc_end])
            self.transitions.extend([t1, t2, t3])
            node.children = []
        return arg

    def visit_bottom(self, type, arg):
        if type == "command_assign":
            self.write_identifier(arg, self.loc_last);
        return arg;

# vim:ts=4:sw=4:expandtab
