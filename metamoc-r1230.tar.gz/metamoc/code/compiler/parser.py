""" 
    Copyright (C) 2008 Andreas Engelbredt Dalsgaard <andreas.dalsgaard@gmail.com>
    and Martin Toft <mt@martintoft.dk>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>. """

from lexer import *

#AST
class Node:
    def __init__(self, type, children=[], leaf=[]):
        self.type = type
        if children:
            self.children = children
        else:
            self.children = [ ]
        self.leaf = leaf

    def visit(self, cg, arg):
        print "visit", self.type
        rarg = cg.visit_top(self.type, self.leaf, self)
        for v in self.children:
            v.visit(cg, rarg);
        cg.visit_bottom(self.type, self.leaf)

# dictionary of names
identifiers = { }

def p_program(p):
    'program : command'
    p[0] = Node("program", [p[1]])
    print "PROGRAM"

def p_command_var(p):
    '''command : VAR IDENTIFIER
               | VAR IDENTIFIER LSQUAREBRACKET NUMBER RSQUAREBRACKET'''
    if len(p) == 3:
        print "COMMAND_VAR", p[2]
        identifiers[p[2]] = 0
        p[0] = Node("command_var", [], p[2])
    else:
        for i in range(0, int(p[4])):
            print "COMMAND_VAR", p[2] + str(i)
            identifiers[p[2] + str(i)] = 0
            p[0] = Node("command_var", [], p[2] + str(i))

def p_command_output(p):
    'command : OUTPUT expression'
    print "COMMAND_OUTPUT", p[2]
    p[0] = Node("command_output", [p[2]])

def p_command_if(p):
    'command : IF LPAREN boolean RPAREN LCURLYPAREN command RCURLYPAREN'
    print "COMMAND_IF", p[1]
    p[0] = Node("command_if", [p[3], p[6]])

def p_command_if_else(p):
    'command : IF LPAREN boolean RPAREN LCURLYPAREN command RCURLYPAREN ELSE LCURLYPAREN command RCURLYPAREN'
    print "COMMAND_IF_ELSE", p[1]
    p[0] = Node("command_if_else", [p[3], p[6], p[10]])

def p_command_while(p):
    'command : WHILE LPAREN boolean RPAREN NUMBER LCURLYPAREN command RCURLYPAREN'
    print "COMMAND_WHILE", p[1]
    p[0] = Node("command_while", [p[3], p[7]], p[5])

def p_command_composition(p):
    'command : command SEMI command'
    print "COMMAND_COMPOSITION", p[1]
    p[0] = Node("command_composition", [p[1], p[3]])

def p_command_assign(p):
    '''command : IDENTIFIER ASSIGN expression
               | IDENTIFIER LSQUAREBRACKET NUMBER RSQUAREBRACKET ASSIGN expression'''
    if len(p) == 7:
        p[1] += str(p[3])
        p[3] = p[6]
    print "COMMAND_ASSIGN", p[1], p[3]
    try:
        tmp = identifiers[p[1]]
    except LookupError:
        print "ERROR: Undefined identifier '%s'" % p[1]
    identifiers[p[1]] = p[3]
    p[0] = Node("command_assign", [p[3]], p[1])

def p_expression_binop(p):
    'expression : expression PLUS expression'
    if p[2] == '+' :
        print "EXPRESSION_BIN_OP", p[0]
        p[0] = Node("expression_binop", [p[1], p[3]])

def p_expression_group(p):
    'expression : LPAREN expression RPAREN'
    p[0] = p[2]
    print "EXPRESSION_GROUP", p[2]
    p[0] = Node("expression_group", [p[2]])

def p_expression_number(p):
    'expression : NUMBER'
    print "EXPRESSION_NUMBER", p[0]
    p[0] = Node("expression_number")

def p_expression_identifier(p):
    '''expression : IDENTIFIER
                  | IDENTIFIER LSQUAREBRACKET NUMBER RSQUAREBRACKET'''
    if len(p) == 5:
        p[1] += str(p[3])
    try:
        t = identifiers[p[1]]
    except LookupError:
        print "ERROR: Undefined identifier '%s'" % p[1]
    print "EXPRESSION_IDENTIFIER"
    p[0] = Node("expression_identifier", [], p[1])

def p_boolean_equal(p):
    'boolean : expression EQUAL expression'
    if p[1] == p[3]:
        p[0] = True
    else:
        p[0] = False
    print "BOOLEAN_EQUAL", p[0]
    p[0] = Node("boolean_equal", [p[1], p[3]])

def p_boolean_less(p):
    'boolean : expression LESS expression'
    if p[1] < p[3]:
        p[0] = True
    else:
        p[0] = False
    print "BOOLEAN_LESS", p[0]
    p[0] = Node("boolean_less", [p[1], p[3]])

def p_boolean_greater(p):
    'boolean : expression GREATER expression'
    if p[1] > p[3]:
        p[0] = True
    else:
        p[0] = False
    print "BOOLEAN_GREATER", p[0]
    p[0] = Node("boolean_greater", [p[1], p[3]])

def p_boolean_not(p):
    'boolean : NOT boolean'
    p[0] = not(p[2])
    print "BOOLEAN_NOT", p[0]
    p[0] = Node("boolean_not", [p[2]])

def p_error(p):
    print "Syntax error at '%s'" % p.value

import ply.yacc as yacc
yacc.yacc()

# vim:ts=4:sw=4:expandtab
