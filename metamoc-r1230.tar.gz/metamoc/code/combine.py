#!/usr/bin/env python

import sys
import cache_gen
import arm_to_uppaal_compiler
from valueanalysis import valueanalysis
import pyuppaal

def combine(pipeline_model, cache_model, mainmemory_model, cfg_model, output_model):
    
    #XXX: Super-gust: templates default value does not work
    ntaOutput = pyuppaal.NTA(templates=[])
    ntaPipeline = pyuppaal.from_xml(open(pipeline_model))       
    ntaCache = pyuppaal.from_xml(open(cache_model))       
    ntaMainMemory = pyuppaal.from_xml(open(mainmemory_model))
    ntaCfg = pyuppaal.from_xml(open(cfg_model))       
    
    ntaOutput.declaration += ntaPipeline.declaration+'\n\n'
    ntaOutput.declaration += ntaMainMemory.declaration+'\n\n'
    ntaOutput.declaration += ntaCfg.declaration+'\n'
    ntaOutput.declaration += ntaCache.declaration+'\n'
    ntaOutput.templates += ntaPipeline.templates
    ntaOutput.templates += ntaCache.templates
    ntaOutput.templates += ntaMainMemory.templates
    ntaOutput.templates += ntaCfg.templates
    lines = ntaCfg.system.splitlines()
    ntaOutput.system += '\n'.join(lines[:len(lines)-1])+'\n'
    ntaOutput.system += ntaPipeline.system
    ntaOutput.system += ''.join(lines[len(lines)-1:])
    
    outf = open(output_model, 'w')
    outf.write(ntaOutput.to_xml())
    outf.close()

def get_pipeline_model(pipeline_options = ''):
    if pipeline_options == 'arm9tdmi':
        return 'models/pipeline_'+pipeline_options+'.xml'
    
def get_cache_model(cache_options = ['', '']):
    cache_model = '/tmp/y5x0rldg_cache_model.xml'
    if cache_options[0] == '': #instruction cache options
        instructionCache = cache_gen.cache_gen('i', 32, 512, 8, 'WRITE_THROUGH', 'NO_WRITE_ALLOCATE', 'FIFO')
    else:
        instructionCache = cache_gen.cache_gen('i', cache_options[0]['blocksize'], \
                cache_options[0]['cachelines'], cache_options[0]['cachesets'], \
                cache_options[0]['write_hit'], cache_options[0]['write_miss'], cache_options[0]['policy'])

    if cache_options[1] == '': #data cache options
        dataCache = cache_gen.cache_gen('d', 32, 512, 8, 'WRITE_BACK', 'WRITE_ALLOCATE', 'FIFO')
    else:
        dataCache = cache_gen.cache_gen('d', cache_options[1]['blocksize'], \
                cache_options[1]['cachelines'], cache_options[1]['cachesets'], \
                cache_options[1]['write_hit'], cache_options[1]['write_miss'], cache_options[1]['policy'])

    instructionCache.templates += dataCache.templates
    cacheDeclarations = instructionCache.declaration.splitlines() + dataCache.declaration.splitlines()
    instructionCache.declaration = '\n'.join(list(set(cacheDeclarations)))
    
    outf = open(cache_model, 'w')
    outf.write(instructionCache.to_xml())
    outf.close()

    return cache_model

def get_mainmemory_model(mainmemory_options = ''):

    if mainmemory_options != '':
        mainmemory_model = '/tmp/tdfsd12.xml'
        file = open('models/mainmemory.xml')
        text = file.read()
        tmpFile = open(mainmemory_model, 'w')
        text = text.replace('MEMFETCH = 33', 'MEMFETCH = '+mainmemory_options)
        tmpFile.write(text)
        tmpFile.close()
    else:
        mainmemory_model = 'models/mainmemory.xml'
        
    return mainmemory_model

def get_cfg_model(cfg_options, print_warnings = True, value_analysis=True):
    cfg_model = '/tmp/a1x6el9g_cfg_model.xml'
    
    value_anal_res = {}
    if value_analysis:
        value_anal_res = valueanalysis.do_valueanalysis(cfg_options)

    arm_to_uppaal_compiler.compile(cfg_options, cfg_model, print_warnings, value_anal_res)
    return cfg_model

def createOptionParser(usage="usage: %prog [options] objfilename outputfilename.xml"):
    from optparse import OptionParser, OptionGroup
    parser = OptionParser(usage=usage)
    parser.add_option("-v", "--verbose",
                  action="store_true", dest="verbose", default=False,
                  help="Print warnings")
    parser.add_option("--no-value-analysis",
                  action="store_false", dest="do_value_analysis", default=True,
                  help="Do not perform value analysis")
    parser.add_option("-p", "--pipeline",
                  dest="pipeline_model", default="arm9tdmi",
                  choices=['arm9tdmi'],
                  help="Pipeline model to use, one of: arm9tdmi")
    parser.add_option("-m", "--memory-latency",
                  dest="memory_latency", default="33", type="int",
                  help="Memory latency in cycles. Default: %default")
    parser.add_option("-r", "--remote-verify",
                  dest="remotehost", default=None,
                  help="Do the verification on a remote host")

    group = OptionGroup(parser, "Cache options",
"""Cache options, of the form
'blocksize,cachelines,cachesets,write_miss_policy,write_hit_policy,replacement_policy'
where:
 * blocksize is the size of the blocks
 * cachelines is TODO
 * cachesets is TODO
 * write_miss_policy is one of: 'WRITE_ALLOCATE' or 'NO_WRITE_ALLOCATE'
 * write_hit_policy is one of: 'WRITE_BACK' or 'WRITE_THROUGH'
 * replacement_policy is one of: 'FIFO' or 'LRU'
The default is:
%default
Alternatively the option 'miss' or 'hit' can be used
""")
    group.add_option("-i", "--instruction-cache",
                  dest="instruction_cache_opts", default="32,512,8,NO_WRITE_ALLOCATE,WRITE_THROUGH,FIFO",
                  help="Instruction Cache. Default: %default")
    group.add_option("-d", "--data-cache",
                  dest="data_cache_opts", default="32,512,8,WRITE_ALLOCATE,WRITE_BACK,FIFO",
                  help="Data Cache. Default: %default")

    parser.add_option_group(group)
    return parser

def main(parser, options, args):
    
    if len(args) != 2:
        parser.error("incorrect number of arguments")

    objfilename = args[0]
    outputfname = args[1]
    print_warnings = options.verbose
    do_value_analysis = options.do_value_analysis

    pipeline_model = get_pipeline_model(options.pipeline_model)

    icopts = {}
    if options.instruction_cache_opts == 'miss':
        instructionCache = cache_gen.cache_gen_always('i', 'miss')
    elif options.instruction_cache_opts == 'hit':
        instructionCache = cache_gen.cache_gen_always('i', 'hit')
    elif len(options.instruction_cache_opts.split(',')) == 6:
        (icopts['blocksize'], 
        icopts['cachelines'],
        icopts['cachesets'],
        icopts['write_miss'],
        icopts['write_hit'],
        icopts['policy'],
        ) = options.instruction_cache_opts.split(',')

        for a in ['blocksize', 'cachelines', 'cachesets']:
            icopts[a] = int(icopts[a])

        instructionCache = cache_gen.cache_gen('i', icopts['blocksize'], \
                icopts['cachelines'], icopts['cachesets'], \
                icopts['write_hit'], icopts['write_miss'], icopts['policy'])
    else:
        parser.error("incorrect instruction cache options")
    


    dcopts = {}
    if options.data_cache_opts == 'miss':
        dataCache = cache_gen.cache_gen_always('d', 'miss')
    elif options.data_cache_opts == 'miss_writeback':
        dataCache = cache_gen.cache_gen_always('d', 'miss_writeback')
    elif options.data_cache_opts == 'hit':
        dataCache = cache_gen.cache_gen_always('d', 'hit')
    elif len(options.data_cache_opts.split(',')) == 6:
        (dcopts['blocksize'], 
        dcopts['cachelines'],
        dcopts['cachesets'],
        dcopts['write_miss'],
        dcopts['write_hit'],
        dcopts['policy'],
        ) = options.data_cache_opts.split(',')

        for a in ['blocksize', 'cachelines', 'cachesets']:
            dcopts[a] = int(dcopts[a])

        dataCache = cache_gen.cache_gen('d', dcopts['blocksize'], \
                dcopts['cachelines'], dcopts['cachesets'], \
                dcopts['write_hit'], dcopts['write_miss'], dcopts['policy'])
    else:
        parser.error("incorrect data cache options")

    #Combine cache models
    cache_model = '/tmp/y5x0rldg_cache_model.xml'
    instructionCache.templates += dataCache.templates
    cacheDeclarations = instructionCache.declaration.splitlines() + dataCache.declaration.splitlines()
    instructionCache.declaration = '\n'.join(list(set(cacheDeclarations)))
    outf = open(cache_model, 'w')
    outf.write(instructionCache.to_xml())
    outf.close()

    mainmemory_model = get_mainmemory_model(str(options.memory_latency))
    cfg_model = get_cfg_model(objfilename, print_warnings, do_value_analysis)
    combine(pipeline_model, cache_model, mainmemory_model, cfg_model, outputfname)

if __name__ == "__main__":
    parser = createOptionParser()
    (options, args) = parser.parse_args()
    main(parser, options, args)
