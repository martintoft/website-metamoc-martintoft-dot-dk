#!/usr/bin/python

import sys
import re
import wali
import dissy.File
from dissy.Function import Function
from dissy.Instruction import Instruction
from dissy.arm import ArmArchitecture

from common import all_loopbound_combinations, find_loopbounds
from arm_to_uppaal_compiler import get_ins_type

#Value found on Debian armel, probably varies from binary to binary...
#STACK_START = 3201554652
STACK_START = 128000 #Agreed, by commitee.


def normalize_regname(regname):
    return {'sl': 'r10', 
            'fp': 'r11', 
            'ip': 'r12', 
            'sp': 'r13',
            'lr': 'r14',
            #'pc': 'r15'
            }.get(regname, regname)

def crossproduct(s1, s2):
    ans = []
    for a in s1:
        for b in s2:
            ans += [a + b]
    return ans


arch = ArmArchitecture()
def getInstructionEffect(ins, func):
    opc = ins.getOpcode()
    (regsread, regswrite, values) = arch.parseArguments(ins)

    if opc == "ldr":
        #PC relative load
        if regsread == ['pc'] and len(values) == 1:
            #Calculate address (+8 to account for pipeline)
            addr = ins.getAddress() + 8 + values[0]
            #Find data
            #data = func.lookup(addr)
            data = [w for w in func.getInstructions() if w.getAddress() == addr][0]
            assert data.getOpcode() == '.word'
            return wali.SemElemPtr( wali.ConstDom(
                normalize_regname(regswrite[0]) + "=" + str(int(data.getArgs(), 16))) )
            #print func.getAll()
    elif opc == 'mov':
        #mov rX, value
        if len(regswrite) == 1 and regsread == [] and len(values) == 1:
            return wali.SemElemPtr( wali.ConstDom(
                normalize_regname(regswrite[0]) + "=" + str(values[0]) ))
        #mov rX, rY
        elif len(regswrite) == 1 and len(regsread) == 1 and len(values) == 0:
            return wali.SemElemPtr( wali.ConstDom(
                normalize_regname(regswrite[0]) + "=" + normalize_regname(regsread[0]) ))
    elif opc == 'add':
        #add rX, rY, value
        if len(regswrite) == 1 and len(regsread) == 1 and len(values) == 1:
            return wali.SemElemPtr( wali.ConstDom(
                normalize_regname(regswrite[0]) + "=" + \
                normalize_regname(regsread[0]) + " + " + str(values[0]) ))
        #add rX, rY, rZ
        elif len(regswrite) == 1 and len(regsread) == 2 and len(values) == 0:
            return wali.SemElemPtr( wali.ConstDom(
                normalize_regname(regswrite[0]) + "=" + \
                normalize_regname(regsread[0]) + " + " + \
                normalize_regname(regsread[1]) ))
    elif opc == 'sub':
        #add rX, rY, value
        if len(regswrite) == 1 and len(regsread) == 1 and len(values) == 1:
            return wali.SemElemPtr( wali.ConstDom(
                normalize_regname(regswrite[0]) + "=" + \
                normalize_regname(regsread[0]) + " - " + str(values[0]) ))
        #add rX, rY, rZ
        elif len(regswrite) == 1 and len(regsread) == 2 and len(values) == 0:
            return wali.SemElemPtr( wali.ConstDom(
                normalize_regname(regswrite[0]) + "=" + \
                normalize_regname(regsread[0]) + " - " + \
                normalize_regname(regsread[1]) ))
    elif opc == 'lsl':
        #TODO XXX - is this totally correct? See 
        #http://en.wikipedia.org/wiki/Arithmetic_shift and
        #http://en.wikipedia.org/wiki/Logical_shift

        #lsl rX, rY, value
        if len(regswrite) == 1 and len(regsread) == 1 and len(values) == 1:
            return wali.SemElemPtr( wali.ConstDom(
                normalize_regname(regswrite[0]) + "=" + \
                normalize_regname(regsread[0]) + " << " + str(values[0]) ))
    elif opc == 'asr':
        #asr rX, rY, value
        if len(regswrite) == 1 and len(regsread) == 1 and len(values) == 1:
            return wali.SemElemPtr( wali.ConstDom(
                normalize_regname(regswrite[0]) + "=" + \
                normalize_regname(regsread[0]) + " >> " + str(values[0]) ))
    elif opc == 'push':
        dataregs = [a for a in regsread if a != 'sp']
        return wali.SemElemPtr( wali.ConstDom(
            normalize_regname('sp') + " = " + normalize_regname('sp') + " - " + \
            str(len(dataregs) * 4)
            ))
    elif opc == 'pop':
        dataregs = [a for a in regswrite if a != 'sp']
        return wali.SemElemPtr( wali.ConstDom(
            "".join(map(lambda x: normalize_regname(x) + " = top ; ", dataregs))+ \
            normalize_regname('sp') + " = " + normalize_regname('sp') + " + " + \
            str(len(dataregs) * 4)
            ))
    
    #unknown effect
    if len(regswrite) > 0:
        return wali.SemElemPtr( wali.ConstDom(
            "".join(map(lambda x: normalize_regname(x) + " = top ; ", regswrite))
            ))

    return wali.SemElemPtr( wali.ConstDom("") )

def getNoEffect():
    return wali.SemElemPtr( wali.ConstDom("") )

def getZeroElement():
    return getNoEffect().zero()


def construct_wpds(f):
    wpds = wali.WPDS()
    #the state of our automaton
    p = wali.getKey("p")

    for func in f.getFunctions():
        if func.getLabel()[0:2] != '__':

            loop_bounds = find_loopbounds(func)
            
            #Copy loopbounds
            cur_loopbounds = dict(loop_bounds)
            for i in cur_loopbounds:
                cur_loopbounds[i] = 0

            #Function start transition
            ins = func.getInstructions()[0]
            k0 = wali.getKey("f_" + func.getLabel())
            k1 = wali.getKey(hex(ins.address)[:-1] + "_" + \
                "_".join(map(str, cur_loopbounds.values())))
            effect = getNoEffect()
            wpds.add_rule(p, k0, p, k1, effect)

            i = 0
            indentlevel = -1
            #for i in range(0, len(func.getInstructions())):
            while i < len(func.getInstructions()):
                ins = func.getInstructions()[i]
                #print i, ins

                #unconditional branch ("Function call")
                if isinstance(ins.getOutLink(), Function): #TODO check that jump is unconditional
                    k0 = wali.getKey(hex(ins.address)[:-1] + "_" + \
                        "_".join(map(str, cur_loopbounds.values())))
                    k1 = wali.getKey("f_" + ins.getOutLink().getLabel())
                    effect = getInstructionEffect(ins, func)

                    #Special case: Function call as last instruction, no return from this call - handle as sort of sequential
                    if len(func.getInstructions()) - 1 == i:
                        wpds.add_rule(p, k0, p, k1, effect)
                        i += 1
                    else:
                        nextins = func.getInstructions()[i+1]
                        i += 1

                        k2 = wali.getKey(hex(nextins.address)[:-1] + "_" + \
                            "_".join(map(str, cur_loopbounds.values())))
                        wpds.add_rule(p, k0, p, k1, k2, effect)
                    continue
                #jump
                elif isinstance(ins.getOutLink(), Instruction) and \
                    not ins.getOpcode() in ['bl', 'bx'] and \
                    len(ins.getOpcode()) > 1:

                    #Forward jump
                    if ins.getOutLink().getAddress() > ins.getAddress():
                        #Jump taken
                        nextins = ins.getOutLink()
                        k0 = wali.getKey(hex(ins.address)[:-1] + "_" + \
                            "_".join(map(str, cur_loopbounds.values())))
                        k1 = wali.getKey(hex(nextins.address)[:-1] + "_" + \
                            "_".join(map(str, cur_loopbounds.values())))
                        effect = getInstructionEffect(ins, func)
                        wpds.add_rule(p, k0, p, k1, effect)

                        if len(ins.getOpcode()) > 1: #Conditional jump, possibility of sequential
                            nextins = func.getInstructions()[i+1]
                            k0 = wali.getKey(hex(ins.address)[:-1] + "_" + \
                                "_".join(map(str, cur_loopbounds.values())))
                            k1 = wali.getKey(hex(nextins.address)[:-1] + "_" + \
                                "_".join(map(str, cur_loopbounds.values())))
                            effect = getInstructionEffect(ins, func)
                            wpds.add_rule(p, k0, p, k1, effect)

                        i += 1
                        continue
                    #Backward jump
                    elif ins.getOutLink().getAddress() < ins.getAddress():
                        #examine loopbound, to find out if we unroll,
                        if cur_loopbounds[ins.getAddress()] <= loop_bounds[ins.getAddress()]:
                            if cur_loopbounds[ins.getAddress()] == 0:
                                indentlevel += 1
                            #print '  ' * indentlevel + 'Unrolling loop at', hex(ins.getAddress())[:-1],
                            #print cur_loopbounds[ins.getAddress()], "/", loop_bounds[ins.getAddress()]

                            #keep unrolling, take loop edge
                            nextins = ins.getOutLink()
                            i = func.getInstructions().index(nextins)
            
                            k0 = wali.getKey(hex(ins.address)[:-1] + "_" + \
                                "_".join(map(str, cur_loopbounds.values())))

                            cur_loopbounds[ins.getAddress()] += 1

                            k1 = wali.getKey(hex(nextins.address)[:-1] + "_" + \
                                "_".join(map(str, cur_loopbounds.values())))
                            effect = getInstructionEffect(ins, func)
                            wpds.add_rule(p, k0, p, k1, effect)

                            continue
                        else:
                            #loopbound reached, go on sequentially
                            nextins = func.getInstructions()[i+1]
                            i += 1

                            k0 = wali.getKey(hex(ins.address)[:-1] + "_" + \
                                "_".join(map(str, cur_loopbounds.values())))

                            #reset loop counter
                            cur_loopbounds[ins.getAddress()] = 0

                            k1 = wali.getKey(hex(nextins.address)[:-1] + "_" + \
                                "_".join(map(str, cur_loopbounds.values())))
                            effect = getInstructionEffect(ins, func)
                            wpds.add_rule(p, k0, p, k1, effect)
                            indentlevel -= 1
                            continue
                    else:
                        assert (False) #Jump to self is crazy

                #"Return"
                elif ins.getOpcode() == 'bx' and ins.getArgs() == 'lr':
                    k0 = wali.getKey(hex(ins.address)[:-1] + "_" + \
                        "_".join(map(str, cur_loopbounds.values())))
                    
                    effect = getInstructionEffect(ins, func)
                    wpds.add_rule(p, k0, p, effect)

                    i += 1
                    continue
                #Sequential progression
                elif i < len(func.getInstructions())-1:
                    nextins = func.getInstructions()[i+1]
                    i += 1
                else:
                    i += 1
                    continue

                k0 = wali.getKey(hex(ins.address)[:-1] + "_" + \
                    "_".join(map(str, cur_loopbounds.values())))
                k1 = wali.getKey(hex(nextins.address)[:-1] + "_" + \
                    "_".join(map(str, cur_loopbounds.values())))
                effect = getInstructionEffect(ins, func)
                wpds.add_rule(p, k0, p, k1, effect)
    return wpds

def calculate_calling_contexts(f, answer):
    """Calculates the combined calling context for each function
    @returns dict from function names -> calling context as SemElem"""

    #the state of our automaton
    p = wali.getKey("p")

    toret = {}
    #Traverse the CFG, from main, looking for function calls
    mainfunc = [func for func in f.getFunctions() if func.getLabel() == 'main'][0]
    toret[mainfunc.getLabel()] = getNoEffect()
    funcqueue = [mainfunc]

    while len(funcqueue) > 0:
        func = funcqueue.pop()

        loop_bounds = find_loopbounds(func)
        
        #print 'traversing func', func.getLabel()
        for ins in func.getInstructions():
            if isinstance(ins.getOutLink(), Function):
                #print 'now at', hex(ins.getAddress())
                f2 = ins.getOutLink()
                
                curcontext = toret.get(f2.getLabel(), None)
                #print "got", curcontext

                #traverse the different loopbound contexts
                for lb in all_loopbound_combinations(loop_bounds.values()):
                    #print 'lb', lb
                    k0 = wali.getKey(hex(ins.address)[:-1] + "_" + \
                        "_".join( map(str, lb) ))
                    try:
                        trans = answer.match(p, k0).asList()[0]
                    except Exception:
                        print lb, wali.key2str(k0)
                    #print "extending", toret.get(func.getLabel()),  "with", trans.weight()
                    thiscontext = toret.get(func.getLabel()).extend(trans.weight())

                    #print "combining", curcontext, "and", thiscontext
                    if curcontext is None:
                        curcontext = thiscontext
                    else:
                        curcontext = curcontext.combine(thiscontext)
                    #print "combine result", curcontext

                toret[f2.getLabel()] = curcontext
                funcqueue += [ins.getOutLink()]

    return toret

def regval_from_value_exprs(value_exprs, reg):
    """
    @param value_exprs is a dict from regname -> expression
    @param reg is the regname to compute the value of
    """
    #find value of register
    regname = normalize_regname(reg)
    env = {}
    val = 'INVALID_ADDRESS'
    if value_exprs.get(regname) == 'top':
        return 'INVALID_ADDRESS'
    try:
        #TODO - needs to set initial values of registers
        #expr = 'r13 = ' + str(STACK_START) + " ; r13 = " + value_exprs.get('r13', 'r13')
        expr = 'r13 = ' + str(STACK_START) + " ; " + regname + " = " + value_exprs.get(regname, regname)
        exec expr in env
        val = env[regname]
    except Exception, e: #XXX yuck
        print "Couldn't evaluate expression", e
    return val

def memory_address_from_instruction(f, calling_contexts, weight, ins):
    addrval = "INVALID_ADDRESS"
    (regsread, regswrite, values) = arch.parseArguments(ins)
    value_exprs = {}
    for e in map(str.strip, str(weight)[1:-1].split(";")):
        if "=" in e:
            (regname, expr) = map(str.strip, e.split("="))
            value_exprs[regname] = expr
    #print value_exprs
    if get_ins_type(ins.getOpcode()) in ['INSTR_PUSH', 'INSTR_POP']:
        addrval = regval_from_value_exprs(value_exprs, "r13")
    elif get_ins_type(ins.getOpcode()) in ['INSTR_STORE', 'INSTR_LOAD', 'INSTR_LOADROTATE']:
        #PC relative load
        if regsread == ['pc'] and len(values) == 1:
            #Calculate address (+8 to account for pipeline)
            addrval = ins.getAddress() + 8 + values[0]
        #Load from address contained in single register
        elif (len(regsread) == 1 and len(values) == 0) or \
            (get_ins_type(ins.getOpcode()) == 'INSTR_STORE' and len(regsread) == 2 and len(values) == 0):
            #find value of register
            reg = normalize_regname(regsread[-1])
            addrval = regval_from_value_exprs(value_exprs, reg)
        #Load from address contained in two registers (base and offset)
        elif (len(regsread) == 2 and len(values) == 0) or \
            (get_ins_type(ins.getOpcode()) == 'INSTR_STORE' and len(regsread) == 3 and len(values) == 0):
            reg1 = regval_from_value_exprs(value_exprs, regsread[-2])
            reg2 = regval_from_value_exprs(value_exprs, regsread[-1])
            #print "At ", str(ins), "found", reg1, "+", reg2
            if not reg1 == 'INVALID_ADDRESS' and not reg2 == 'INVALID_ADDRESS':
                addrval = reg1 + reg2
            
    return addrval


def calculate_memaccesses(f, calling_contexts, answer):
    """Calculates the memory address accessed by a memory operation.
    @returns a dict from memory address of instruction -> memory address,
        or -> dict of loop bounds -> memory address, if function uses loop bounds.
    """
    #the state of our automaton
    p = wali.getKey("p")

    toret = {}

    for func in f.getFunctions():
        if func.getLabel()[0:2] == '__':
            continue
        loop_bounds = find_loopbounds(func)
        for ins in func.getInstructions():
            if get_ins_type(ins.getOpcode()) in \
                ['INSTR_STORE', 'INSTR_LOAD', 'INSTR_PUSH', 'INSTR_POP',
                 'INSTR_LOADROTATE']:
                if len(loop_bounds.values()) == 0:
                    k0 = wali.getKey(hex(ins.address)[:-1] + "_")
                    trans = answer.match(p, k0).asList()[0]
                    #print "extending", calling_contexts[func.getLabel()],
                    #print "with", trans.weight(),
                    weight = calling_contexts[func.getLabel()].extend(trans.weight())
                    #print "=", weight
                    #print hex(ins.getAddress()), str(ins), weight
                    #find out address, by evaluating expression, given weight



                    toret[ins.getAddress()] = memory_address_from_instruction(f, calling_contexts, weight, ins)
                else:
                    context_dict = {}
                    #traverse the different loopbound contexts
                    for lb in all_loopbound_combinations(loop_bounds.values()):
                        k0 = wali.getKey(hex(ins.address)[:-1] + "_" + \
                            "_".join( map(str, lb) ))
                        transitions = answer.match(p, k0).asList()
                        assert(len(transitions) in [0, 1])
                        if len(transitions) == 1:
                            trans = transitions[0]
                            weight = calling_contexts[func.getLabel()].extend(trans.weight())
                            #print "extending", calling_contexts[func.getLabel()], "with", trans.weight(),
                            #print "=", weight
                            #print hex(ins.getAddress()), lb, str(ins), weight
                            addrval = memory_address_from_instruction(f, calling_contexts, weight, ins)
                            if addrval != 'INVALID_ADDRESS':
                                context_dict[lb] = addrval
                    toret[ins.getAddress()] = context_dict
    return toret

def do_valueanalysis(fname):
    #construct WPDS
    f = dissy.File.File(fname)
    for func in f.getFunctions():
        func.parse()
        func.link()
    res = construct_wpds(f)

    #Compute the result
    query = wali.WFA()
    p = wali.getKey("p")
    accept = wali.getKey("accept")
    initloc = wali.getKey("f_main")
    query.addTrans( p, initloc  , accept, getNoEffect() );
    query.set_initial_state( p )
    query.add_final_state( accept )
    answer = wali.WFA()
    res.poststar(query, answer)

    #post-process the result
    calling_contexts = calculate_calling_contexts(f, answer)
    mem_accesses = calculate_memaccesses(f, calling_contexts, answer)
    return mem_accesses

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print "Usage: %s objfilename" % (sys.argv[0])
        sys.exit(1)

    fname = sys.argv[1]

    verbose = False
    if len(sys.argv) > 2 and sys.argv[2] == '-v':
        verbose = True
        verbosefile = open('/tmp/value-analysis-out.txt', 'w')

    f = dissy.File.File(fname)
    for func in f.getFunctions():
        func.parse()
        func.link()
    res = construct_wpds(f)

    print "=================== WPDS constructed =============="

    if verbose:
        #Sort output, by address ;-)
        lines = str(res).split("\n")
        lines.sort()
        verbosefile.write("=== WPDS ===\n")
        verbosefile.write('\n'.join(lines))
        verbosefile.write("\n\n\n")

    #TEST
    query = wali.WFA()
    p = wali.getKey("p")
    accept = wali.getKey("accept")
    initloc = wali.getKey("f_main")

    query.addTrans( p, initloc  , accept, getNoEffect() );

    query.set_initial_state( p )
    query.add_final_state( accept )

    if verbose:
        print "============== ANSWER ==============="

    answer = wali.WFA()
    res.poststar(query, answer)
    
    if verbose:
        print "done"
        verbosefile.write("=== Answer ===\n")
        verbosefile.write( str(answer) )
        verbosefile.write("\n\n\n")

    calling_contexts = calculate_calling_contexts(f, answer)
    if verbose:
        verbosefile.write("=== Calling Contexts ===\n")
        for k in calling_contexts:
            verbosefile.write( k + ": " + str(calling_contexts[k]) + "\n")
        verbosefile.write("\n\n\n")

    mem_accesses = calculate_memaccesses(f, calling_contexts, answer)
    if verbose:
        mem_access_addrs = mem_accesses.keys()
        mem_access_addrs.sort()
        verbosefile.write("=== Memory Accesses ===\n")
        for addr in mem_access_addrs:
            #if isinstance(mem_accesses[addr], dict):
            #    print hex(addr)[:-1], ":",
            #    lbcs = mem_accesses[addr].keys()
            #    lbcs.sort()
            #    for lbc in lbcs:
            #        pass
            #        pass
            #        print lbc, ":", mem_accesses[addr][lbc]
            #        #print ""
            #        #a = 42
            #        pass
            #else:
            verbosefile.write(hex(addr)[:-1] + ": " + str(mem_accesses[addr]) + "\n")
        verbosefile.write("\n\n\n")

    #f = open('/tmp/lalala.dot', 'w')
    #f.write(answer.print_dot())
    #f.close()

    sys.exit(0)
