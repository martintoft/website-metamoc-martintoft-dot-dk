#!/usr/bin/python

import wali

"""
class Reach(wali.SemElem):
    numReaches = 0

    def __init__(self, b):
        self.isreached = b
        Reach.numReaches += 1
        #wali.SemElemPtr.__init__(self)
        wali.SemElem.__init__(self)

    #def __del__(self):
    #    Reach.numReaches -= 1

    def one(self):
        return O

    def zero(self):
        return Z

    def extend(self, se):
        return Reach(self.isreached and se.isreached)
        
    def combine(self, se):
        return Reach(self.isreached or se.isreached)

    def equal(self, se):
        return (self.isreached == se.isreached)

    def __str__(self):
        return (self.isreached and "ONE" or "ZERO")

O = Reach(True)
Z = Reach(False)
"""

reachOne = wali.Reach(True)
reachOnePtr = wali.SemElemPtr(reachOne)
#reachOne = wali.SemElemPtr()

reachZero = wali.Reach(False)
reachZeroPtr = wali.SemElemPtr(reachZero)


myWpds = wali.FWPDS()
p = wali.getKey("p")
accept = wali.getKey("accept")

n = []
for i in range(0, 12):
    n += [wali.getKey("n" + str(i))]

#f intraprocedural
myWpds.add_rule(p, n[0], p, n[1], reachOnePtr)
myWpds.add_rule( p, n[0], p, n[1], reachOnePtr)
myWpds.add_rule( p, n[1], p, n[2], reachOnePtr)
myWpds.add_rule( p, n[1], p, n[3], reachOnePtr)
myWpds.add_rule( p, n[2], p, n[4], reachOnePtr)
myWpds.add_rule( p, n[3], p, n[4], reachOnePtr)

#g intraprocedural
myWpds.add_rule( p, n[6], p, n[7], reachOnePtr)
myWpds.add_rule( p, n[7], p, n[8], reachOnePtr)
myWpds.add_rule( p, n[8], p, n[9], reachOnePtr)

#f call g
myWpds.add_rule( p, n[4], p, n[6], n[5], reachOnePtr)
#f return
myWpds.add_rule( p, n[5] , p , reachOnePtr)
#g return
myWpds.add_rule( p, n[9] , p , reachOnePtr)

#disconnected hejs
myWpds.add_rule( p, n[10], p, n[11], reachOnePtr)

print str(myWpds)

# Perform poststar query
query = wali.WFA()
query.addTrans( p, n[0], accept, reachOnePtr);
query.set_initial_state( p )
query.add_final_state( accept )
print "BEFORE poststar"
print str(query)

answer = wali.WFA()
myWpds.poststar(query, answer)
print "AFTER poststar"
print str(answer)

#Perform prestar query
prequery = wali.WFA()
prequery.addTrans( p, n[4], accept, reachOnePtr )
prequery.set_initial_state( p )
prequery.add_final_state( accept )
print "BEFORE prestar"
print str(prequery)

answer = wali.WFA()
myWpds.prestar(prequery,answer);
print "AFTER poststar"
print str(answer)

