#!/bin/sh
. /usr/local/openmoko/arm/setup-env
export PYTHONPATH=`pwd`/../externals/pyuppaal/:`pwd`/../externals/dissy:`pwd`/
export LD_LIBRARY_PATH=`pwd`/../externals/wali/lib/

