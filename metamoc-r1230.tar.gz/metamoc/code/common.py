#!/usr/bin/python
from dissy.Instruction import Instruction
import re

def all_loopbound_combinations(max_loopbounds):
    if len(max_loopbounds) == 0:
        yield ()
    elif len(max_loopbounds) == 1:
        for i in range(0, max_loopbounds[0]):
            yield (i, )
    else:
        for i in range(0, max_loopbounds[0]):
            for j in all_loopbound_combinations(max_loopbounds[1:]):
                yield tuple([i] + list(j))

def set_last_loop_bound(line, last_loop_bound):
    p = re.compile('@loop_bound\ ([0-9]+)')
    l = p.findall(str(line))
    if len(l) > 0:
        return l[len(l)-1]
    else:
        return last_loop_bound

library_function_loopbounds = {
    #TODO XXX - I have _NO_ idea if these bounds are correct - mchro
    '__divsi3': {
        0x50: 5,
        0x64: 5,
        0xa8: 5,
    },
    #TODO XXX - I have _NO_ idea if these bounds are correct - mchro
    '__udivsi3': {
        0x3c: 5,
        0x50: 5,
        0x94: 5,
    },
    '__aeabi_uidivmod': { }
}
handled_library_functions = library_function_loopbounds.keys()

def find_loopbounds(func):
    loop_bounds = {}

    #Is library function?
    if func.getLabel() in library_function_loopbounds:
        library_loop_bounds = library_function_loopbounds[func.getLabel()]
        for i in library_loop_bounds:
            loop_bounds[func.getAddress() + i] = library_loop_bounds[i]
        return loop_bounds
    
    #find loop bounds
    last_loop_bound = 'NO_LOOP_BOUND'
    for line in func.getAll():
        if isinstance(line, Instruction):
            other = line.getOutLink()
            if isinstance(other, Instruction) and other != line:
                if other.getAddress() < line.getAddress(): # BACKWARDS jump
                    if last_loop_bound != 'NO_LOOP_BOUND':
                        loop_bounds[line.getAddress()] = int(last_loop_bound)
                    else:
                        loop_bounds[line.getAddress()] = last_loop_bound
        else:
            last_loop_bound = set_last_loop_bound(line, last_loop_bound)
    return loop_bounds

