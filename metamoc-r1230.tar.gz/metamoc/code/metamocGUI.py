#!/usr/bin/python

"""
    This program is a graphical user interface for pyuppaal. It uses goocanvas and 
    was initially inspired from examples included in the python bindings of goocanvas.

    Copyright (C) 2008 Andreas Engelbredt Dalsgaard <andreas.dalsgaard@gmail.com>
                       Mads Christian Olesen <mchro@cs.aau.dk>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>. """


import gtk
import os
import gtk.glade
import sys
import vte
import gobject
import verify_wcet
import time

global pipelineStore

class Pipeline:
    def __init__(self, name = '', model = ''):
        self.name = name
        self.model = model

class PipelineStore:
    def __init__(self):
        self.pipelineStore = gtk.ListStore(str, gobject.TYPE_PYOBJECT)
        for p in [Pipeline(name='ARM9TDMI', model='models/pipeline_arm9tdmi.xml'), Pipeline(name='h8/300', model='models/pipeline_h8_300.xml')]:
            self.pipelineStore.append([p.name, p])

    def getIndex(self, pipelineName):
        i = 0
        for p in self.pipelineStore:
            if p[0] == pipelineName:
                return i
            i = i + 1
        return 0
    
    def getPipeline(self, pipelineName):
        for p in self.pipelineStore:
            if p[0] == pipelineName:
                return p[1]
        return None 
    
class Platform:
    def __init__(self, name = '', objdump = '', pipeline = '', cache = '', mainmemoryNumber = '33'):
        self.name = name
        self.objdump = objdump
        self.pipeline = pipeline
        self.cache = cache
        self.mainmemoryNumber = mainmemoryNumber

class PlatfromSettingWindow:
    def __init__(self, wTree, liststore, cacheWin):
        self.cacheWin = cacheWin
        self.platformSettingsWin = wTree.get_widget("platformSettings")
        self.platformSettingsWin.connect ("delete-event", self.hide)
        self.treeView = wTree.get_widget("platformTreeview")
        col = gtk.TreeViewColumn("Platforms", gtk.CellRendererText(), text=0)
        self.treeView.append_column(col)
        self.liststore = liststore
        self.treeView.set_model(self.liststore)
        self.name = wTree.get_widget("name")
        self.objdump = wTree.get_widget("objdump")
        self.pipeline = wTree.get_widget("pipeline")

        global pipelineStore
        self.pipeline.set_model(pipelineStore.pipelineStore)
        cell = gtk.CellRendererText()
        self.pipeline.pack_start(cell, True)
        self.pipeline.add_attribute(cell, 'text', 0)  
        self.pipeline.set_active(0)

        self.mainmemoryNumber = wTree.get_widget("entryMMnr")

        self.add_btn = wTree.get_widget("add")
        self.apply_btn = wTree.get_widget("apply")
        self.close_btn = wTree.get_widget("close")
        self.btnICacheSettings = wTree.get_widget("btnICacheSettings")
        self.btnDCacheSettings = wTree.get_widget("btnDCacheSettings")
        self.add_btn.connect ("clicked", self.on_add_clicked)
        self.apply_btn.connect ("clicked", self.apply)
        self.close_btn.connect ("clicked", self.hide)
        self.treeView.connect ("cursor-changed", self.on_select)
        iter = self.liststore.get_iter_first()
        if iter != None:
            self.selected_platform = self.liststore.get_value(iter, 1)
            self.load(self.selected_platform)
        else:
            print 'Error: platform liststore should not be empty'

    def on_add_clicked(self, widget):
        p = Platform(name='New platform')
        self.liststore.append([p.name, p])
        self.treeView.set_model(self.liststore)

    def get_platform(self):
        treeselection = self.treeView.get_selection()
        (model, iter) = treeselection.get_selected()
        if iter != None:
            return self.liststore.get_value(iter, 1)

        return None
    
    def hide(self, widget, window = None):
        self.save(self.selected_platform)
        self.platformSettingsWin.hide_all()
        return True

    def show(self):
        self.platformSettingsWin.show_all()

    def apply(self, widget):
        self.save(self.selected_platform)
     
    def save(self, platform):
        global pipelineStore
        platform.name = self.name.get_text()
        platform.objdump = self.objdump.get_text()
        platform.mainmemoryNumber = int(self.mainmemoryNumber.get_text())
        platform.pipeline = pipelineStore.pipelineStore.get_value(self.pipeline.get_active_iter(), 1).name
        platform.cache = [self.icache, self.dcache]
        self.update_liststore(platform)
    
    def update_liststore(self, platform):
        for p in self.liststore:
            if p[1] == platform:
                p[0] = platform.name

    def load(self, platform):
        global pipelineStore
        self.name.set_text(platform.name)
        self.objdump.set_text(platform.objdump)
        self.mainmemoryNumber.set_text(str(platform.mainmemoryNumber))
        index = pipelineStore.getIndex(platform.pipeline)
        self.pipeline.set_active(index)
        self.icache = platform.cache[0]
        self.dcache = platform.cache[1]
        self.icache.update_label()
        self.dcache.update_label()
        self.btnICacheSettings.connect("clicked", self.cacheWin.show, self.icache)
        self.btnDCacheSettings.connect("clicked", self.cacheWin.show, self.dcache)

    def on_select(self, widget):
        platform = self.get_platform()
        if platform != None:
            self.selected_platform = platform 
            self.load(self.selected_platform)

class Cache:
    def __init__(self, blocksize, cachelines, cachesets, writeHit, writeMiss, policy, label):
        self.blocksize = blocksize
        self.cachelines = cachelines
        self.cachesets = cachesets
        self.writeHit = writeHit
        self.writeMiss = writeMiss
        self.policy = policy
        self.label = label
 
    def get_resume(self):
        if self.writeHit == 'WRITE_THROUGH':
            WH = 'WT'
        else:
            WH = 'WB'
            
        if self.writeMiss == 'WRITE_ALLOCATE':
            WM = 'WA'
        else:
            WM = 'NWA'

        return str(self.blocksize)+':'+str(self.cachelines)+':'+str(self.cachesets)+':'+WH+':'+WM+':'+self.policy

    def get_str(self):
        return ' '+str(self.blocksize)+' '+str(self.cachelines)+' '+str(self.cachesets)+' '+self.writeHit+' '+self.writeMiss+' '+self.policy

    def update_label(self):
        self.label.set_text(self.get_resume())

class CacheSettingWindow:
    def __init__(self, wTree):
        self.cacheSettingsWin = wTree.get_widget("cacheSettings")
        self.cacheSettingsWin.connect ("delete-event", self.hide)
        self.blocksize = wTree.get_widget("entryBlockSize")
        self.cachelines = wTree.get_widget("entryCachelines")
        self.cachesets = wTree.get_widget("entryCachesets")
        self.comboMiss = wTree.get_widget("comboMiss")
        self.comboHit = wTree.get_widget("comboHit")
        self.comboPolicy = wTree.get_widget("comboPolicy")
        self.okay_btn = wTree.get_widget("buttonOkay")
        self.okay_btn.connect ("clicked", self.hide)
        self.liststorePolicy = gtk.ListStore(str)
        self.liststorePolicy.append(['FIFO'])
        self.liststorePolicy.append(['LRU'])
        self.liststoreWH = gtk.ListStore(str, str)
        self.liststoreWH.append(['Write Through', 'WRITE_THROUGH'])
        self.liststoreWH.append(['Write Back', 'WRITE_BACK'])
        self.liststoreWM = gtk.ListStore(str, str)
        self.liststoreWM.append(['No Write Allocate', 'NO_WRITE_ALLOCATE'])
        self.liststoreWM.append(['Write Allocate', 'WRITE_ALLOCATE'])
        self.comboHit = wTree.get_widget("comboHit")
        self.comboMiss = wTree.get_widget("comboMiss")
        self.comboPolicy = wTree.get_widget("comboPolicy")
        self.comboHit.set_model(self.liststoreWH)
        self.comboMiss.set_model(self.liststoreWM)
        self.comboPolicy.set_model(self.liststorePolicy)
        self.comboHit.set_active(0)
        self.comboMiss.set_active(0)
        self.comboPolicy.set_active(0)

    def hide(self, widget, window = None):
        self.cacheSettingsWin.hide_all()
        self.save()
        return True

    def show(self, widget, cache):
        self.cache = cache
        self.load()
        self.cacheSettingsWin.show_all()

    def save(self):
        self.cache.blocksize = int(self.blocksize.get_text())
        self.cache.cachelines = int(self.cachelines.get_text())
        self.cache.cachesets = int(self.cachesets.get_text())
        missModel = self.comboMiss.get_model()
        self.cache.writeMiss = missModel.get_value(self.comboMiss.get_active_iter(), 1)
        hitModel = self.comboHit.get_model()
        self.cache.writeHit = hitModel.get_value(self.comboHit.get_active_iter(), 1)
        policyModel = self.comboPolicy.get_model()
        self.cache.policy = policyModel.get_value(self.comboPolicy.get_active_iter(), 0)
        self.cache.update_label()
    
    def load(self):
        self.blocksize.set_text(str(self.cache.blocksize))
        self.cachelines.set_text(str(self.cache.cachelines))
        self.cachesets.set_text(str(self.cache.cachesets))
        index = self.get_index(self.comboMiss.get_model(), self.cache.writeMiss, 1)
        self.comboMiss.set_active(index)
        index = self.get_index(self.comboHit.get_model(), self.cache.writeHit, 1)
        self.comboHit.set_active(index)
        index = self.get_index(self.comboPolicy.get_model(), self.cache.policy, 0)
        self.comboPolicy.set_active(index)

    def get_index(self, model, value, model_index):
        i = 0
        for v in model:
            if value == v[model_index]:
                return i
            i = i + 1
        return -1
    


class MainWindow:

    def __init__(self):
        #init pipeline store
        global pipelineStore
        pipelineStore = PipelineStore()

        #Set the Glade file
        self.gladefile = os.path.join("data", "metamocGUI.glade")
        self.wTree = gtk.glade.XML(self.gladefile)

        self.instructionCacheLabel = self.wTree.get_widget("instructionCacheLabel")
        self.dataCacheLabel = self.wTree.get_widget("dataCacheLabel")
        
        #init platform list
        self.liststore = gtk.ListStore(str, gobject.TYPE_PYOBJECT)
        platformList = [Platform(name='ARM920T', objdump='arm-angstrom-linux-gnueabi-objdump', pipeline = 'ARM9TDMI', \
                        cache = [Cache(32, 512, 8, 'WRITE_THROUGH', 'NO_WRITE_ALLOCATE', 'FIFO', self.instructionCacheLabel), \
                                Cache(32, 512, 8, 'WRITE_BACK', 'WRITE_ALLOCATE', 'FIFO', self.dataCacheLabel)], mainmemoryNumber = 33), \
                        Platform(name='ARM922T', pipeline='h8/300', \
                                cache = [Cache(8, 128, 8, 'WRITE_THROUGH', 'NO_WRITE_ALLOCATE', 'FIFO', self.instructionCacheLabel), \
                                Cache(8, 128, 8, 'WRITE_BACK', 'WRITE_ALLOCATE', 'FIFO', self.dataCacheLabel)], mainmemoryNumber = 10),
                        Platform(name='ARM940T', pipeline='h8/300', \
                                cache = [Cache(8, 128, 8, 'WRITE_THROUGH', 'NO_WRITE_ALLOCATE', 'FIFO', self.instructionCacheLabel), \
                                Cache(8, 128, 8, 'WRITE_BACK', 'WRITE_ALLOCATE', 'FIFO', self.dataCacheLabel)], mainmemoryNumber = 10),
                        Platform(name='Fictive ARM w/quick mem.', objdump='arm-angstrom-linux-gnueabi-objdump', pipeline = 'ARM9TDMI', \
                        cache = [Cache(32, 512, 8, 'WRITE_THROUGH', 'NO_WRITE_ALLOCATE', 'FIFO', self.instructionCacheLabel), \
                                Cache(32, 512, 8, 'WRITE_BACK', 'WRITE_ALLOCATE', 'FIFO', self.dataCacheLabel)], mainmemoryNumber = 10), \
                        Platform(name='Fictive ARM w/LRU caches', objdump='arm-angstrom-linux-gnueabi-objdump', pipeline = 'ARM9TDMI', \
                        cache = [Cache(32, 512, 8, 'WRITE_THROUGH', 'NO_WRITE_ALLOCATE', 'LRU', self.instructionCacheLabel), \
                                Cache(32, 512, 8, 'WRITE_BACK', 'WRITE_ALLOCATE', 'LRU', self.dataCacheLabel)], mainmemoryNumber = 33), \

                                ]
        for p in platformList:
            self.liststore.append([p.name, p])

        self.platform = platformList[0]
        self.platformCombo = self.wTree.get_widget("platformCombo")
        self.platformCombo.set_model(self.liststore)
        cell = gtk.CellRendererText()
        self.platformCombo.pack_start(cell, True)
        self.platformCombo.add_attribute(cell, 'text', 0)  
        self.platformCombo.set_active(0)

        self.mainWin = self.wTree.get_widget("mainWindow")
        self.mainWin.connect ("destroy", gtk.main_quit)
        
        self.cacheSettingsWindow = CacheSettingWindow(self.wTree)
        self.platformSettingsWindow = PlatfromSettingWindow(self.wTree, self.liststore, self.cacheSettingsWindow)

        self.wTree.signal_autoconnect(self)
        self.vte = vte.Terminal ()
        self.vte.fork_command('') 
        self.vte.set_scrollback_lines(100)

        self.vbox6 = self.wTree.get_widget("vbox6")
        self.vbox6.add(self.vte)
        self.vbox6.show_all()
        
        self.filename = None

        self.mainWin.show_all ()

    def set_terminal_output(self, text):
        self.vte.feed(text, len(text))

    def on_platfrom_settings_clicked(self, widget):
        self.platformSettingsWindow.show()

    def on_quit(self, widget):
        gtk.main_quit()

    def on_open(self, widget):
        file_open = gtk.FileChooserDialog(title="Open object file", 
            action=gtk.FILE_CHOOSER_ACTION_OPEN,
                buttons=(gtk.STOCK_CANCEL,
                        gtk.RESPONSE_CANCEL,
                        gtk.STOCK_OPEN,
                        gtk.RESPONSE_OK))
        filter = gtk.FileFilter()
        filter.set_name("Object files")
        filter.add_pattern("*.o")
        file_open.add_filter(filter)
        filter = gtk.FileFilter()
        filter.set_name("All files")
        filter.add_pattern("*")
        file_open.add_filter(filter)

        if file_open.run() == gtk.RESPONSE_OK:
            filename = file_open.get_filename()
            file_open.destroy()
        else:
            file_open.destroy()
            return
        self.filename = filename

    def on_platformCombo_changed(self, widget):
        self.platform = self.liststore.get_value(self.platformCombo.get_active_iter(), 1)

    def on_ok_clicked(self, widget):
        global pipelineStore
        if self.filename != None:
            self.vte.hide()
            self.vbox6.remove(self.vte)
            self.vte = vte.Terminal ()
            self.vte.fork_command()
            self.vbox6.add(self.vte)
            self.vbox6.show_all()
            pipeline_model = pipelineStore.getPipeline(self.platform.pipeline).model
            cache_options = self.platform.cache[0].get_str()
            cache_options += self.platform.cache[1].get_str()
            self.vte.feed_child('./embed_verify ' + self.filename  + ' ' + pipeline_model + cache_options + ' ' + str(self.platform.mainmemoryNumber) + ' && exit \n')

def main ():
    window = MainWindow()
    
    if len(sys.argv) > 1:
        window.filename = sys.argv[1]
    gtk.main ()

if __name__ == "__main__":
    main()

# vim:ts=4:sw=4:expandtab
