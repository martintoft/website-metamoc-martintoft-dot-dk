#!/usr/bin/env python

import sys
import cache_gen
import arm_to_uppaal_compiler
from sets import Set
import pyuppaal
import combine
import verify_wcet

if __name__ == "__main__":
    if len(sys.argv) < 14:
        print 'Usage: %s objfilename pipelinemodel cachemodel mainmemorymodel' % (sys.argv[0])
        sys.exit(1)
    output_model = '/tmp/a1x6el9g_cfg_model.xml'
    objfilename = sys.argv[1]
    pipeline_model = sys.argv[2]
    icBlocksize = int(sys.argv[3])
    icCachelines = int(sys.argv[4])
    icCachesets = int(sys.argv[5])
    icWH = sys.argv[6]
    icWM = sys.argv[7]
    icPolicy = sys.argv[8]
    
    dcBlocksize = int(sys.argv[9])
    dcCachelines = int(sys.argv[10])
    dcCachesets = int(sys.argv[11])
    dcWH = sys.argv[12]
    dcWM = sys.argv[13]
    dcPolicy = sys.argv[14]

    mainMemoryNr = sys.argv[15]

    cache_model = combine.get_cache_model([{'blocksize' : icBlocksize, 'cachelines' : icCachelines, 'cachesets' : icCachesets, 'write_miss' : icWM, 'write_hit' : icWH, 'policy' : icPolicy}, {'blocksize' : dcBlocksize, 'cachelines' : dcCachelines, 'cachesets' : dcCachesets, 'write_miss' : dcWM, 'write_hit' : dcWH, 'policy' : dcPolicy}])
    mainmemory_model = combine.get_mainmemory_model(mainMemoryNr)
    cfg_model = combine.get_cfg_model(objfilename, False)
    combine.combine(pipeline_model, cache_model, mainmemory_model, cfg_model, output_model)
    wcet = verify_wcet.verify_wcet(modelfilename=output_model)
    print '\nWCET is ' + str(wcet) + ' cycles\n'
    
   
