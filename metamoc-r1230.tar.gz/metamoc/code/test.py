#!/usr/bin/env python

import sys
import cache_gen
import arm_to_uppaal_compiler
from sets import Set
import pyuppaal
import combine
import verify_wcet
import unittest
import os

class TestAPI(unittest.TestCase):

    def create_cache_model(self, name, WM, WH, policy):
        empty_model = '/tmp/us5ksa07s_empty_model.xml'
        nta_empty = pyuppaal.NTA(templates = [])
        outf = open(empty_model, 'w')
        outf.write(nta_empty.to_xml())
        outf.close()
        cache_model = combine.get_cache_model([{'blocksize' : 8, 'cachelines' : 512, 'cachesets' : 8, 'write_hit' : WH, 'write_miss' : WM, 'policy' : policy}, {'blocksize' : 8, 'cachelines' : 512, 'cachesets' : 8, 'write_hit' : WH, 'write_miss' : WM, 'policy' : policy}])
        mainmemory_model = combine.get_mainmemory_model()
        cfg_model = 'tests/'+name+'.xml'

        combine.combine(empty_model, cache_model, mainmemory_model, cfg_model, '/tmp/oq3ys8_'+name+'.xml')
        return '/tmp/oq3ys8_'+name+'.xml'

    def create_simple_model(self, name):
        pipeline_model = combine.get_pipeline_model('arm9tdmi')
        cache_model = 'models/cache_simple.xml'
        mainmemory_model = combine.get_mainmemory_model('1')

        f = open('tests/' + name + '.xml', 'r')
        stall_nta = pyuppaal.from_xml(f)
        f.close()
        cfg_nta = pyuppaal.NTA(templates = [])
        cfg_nta.add_template(stall_nta.templates[-1])
        cfg_model = '/tmp/us5ksa07s_cfg_model.xml'
        f = open(cfg_model, 'w')
        f.write(cfg_nta.to_xml())
        f.close()

        combined_model = '/tmp/oq3ys8_'+name+'.xml'
        combine.combine(pipeline_model, cache_model, mainmemory_model, cfg_model, combined_model)

        # Fix stuff
        f = open(combined_model, 'r')
        combined_nta = pyuppaal.from_xml(f)
        f.close()
        combined_nta.system = 'main = mainTemplate();' + combined_nta.system + \
                              'main;'
        f = open(combined_model, 'w')
        f.write(combined_nta.to_xml())
        f.close()

        return combined_model

    def assertWcet(self, model, wcet):
        correct_wcet = verify_wcet.verify_wcet(model)
        self.assertEqual(wcet, correct_wcet)

    def test_cache_FIFO_WA_WB_read(self):
        model = self.create_cache_model('WA_WB_read', 'WRITE_ALLOCATE', 'WRITE_BACK', 'FIFO')
        self.assertWcet(model, 34)

    def test_cache_FIFO_NWA_WT_read(self):
        model = self.create_cache_model('NWA_WT_read', 'NO_WRITE_ALLOCATE', 'WRITE_THROUGH', 'FIFO')
        self.assertWcet(model, 34)

    def test_cache_FIFO_WA_WB_write(self):
        model = self.create_cache_model('WA_WB_write', 'WRITE_ALLOCATE', 'WRITE_BACK', 'FIFO')
        self.assertWcet(model, 34)

    def test_cache_FIFO_NWA_WT_write(self):
        model = self.create_cache_model('NWA_WT_write', 'NO_WRITE_ALLOCATE', 'WRITE_THROUGH', 'FIFO')
        self.assertWcet(model, 66)

    def test_cache_LRU_WA_WB_read(self):
        model = self.create_cache_model('WA_WB_read', 'WRITE_ALLOCATE', 'WRITE_BACK', 'LRU')
        self.assertWcet(model, 34)

    def test_cache_LRU_NWA_WT_read(self):
        model = self.create_cache_model('NWA_WT_read', 'NO_WRITE_ALLOCATE', 'WRITE_THROUGH', 'LRU')
        self.assertWcet(model, 34)

    def test_cache_LRU_WA_WB_write(self):
        model = self.create_cache_model('WA_WB_write', 'WRITE_ALLOCATE', 'WRITE_BACK', 'LRU')
        self.assertWcet(model, 34)

    def test_cache_LRU_NWA_WT_write(self):
        model = self.create_cache_model('NWA_WT_write', 'NO_WRITE_ALLOCATE', 'WRITE_THROUGH', 'LRU')
        self.assertWcet(model, 66)

    def test_pipeline_stall1(self):
        model = self.create_simple_model('stall1')
        self.assertWcet(model, 7)

    def test_pipeline_stall2(self):
        model = self.create_simple_model('stall2')
        self.assertWcet(model, 8)

    def test_pipeline_stall3(self):
        model = self.create_simple_model('stall3')
        self.assertWcet(model, 8)

    def test_pipeline_stall4(self):
        model = self.create_simple_model('stall4')
        self.assertWcet(model, 9)

    def test_instruction_data_concurrent_memory_access(self):
        model = self.create_cache_model('concurrent_reads', 'WRITE_ALLOCATE', 'WRITE_BACK', 'FIFO')
        self.assertWcet(model, 66)

if __name__ == "__main__":
    unittest.main()

